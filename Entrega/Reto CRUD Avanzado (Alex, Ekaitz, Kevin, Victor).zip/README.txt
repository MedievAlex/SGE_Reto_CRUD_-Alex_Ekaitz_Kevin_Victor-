[RESPONSABLES DE VENTANAS]

- INCIDENCIAS: Alex Irazola
- COMENTARIO: Alex Irazola
- ENCUESTA: Ekaitz Campo
- ESTADISTICA: Kevin Salamea
- ADJUNTO: Victor Sabatel
